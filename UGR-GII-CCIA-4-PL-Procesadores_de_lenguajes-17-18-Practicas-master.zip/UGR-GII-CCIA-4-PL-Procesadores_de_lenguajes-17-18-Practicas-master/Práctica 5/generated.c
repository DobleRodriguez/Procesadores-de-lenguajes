#include <stdio.h>
int ve;
float vf;
char vc;
int vl;
int valor;
int main(){
int e1;
scanf("%d",&"introduzca dos caracteres: ");
printf("%c",vc);

}
